import _ from "lodash";
import { useEffect } from "react";
import { Button, Card, Col, Form, Input, Row, Select } from "antd";
import { SaveOutlined } from "@ant-design/icons";
import { useUserForm } from "@hooks/use-users";
import { User, UserPartial } from "@models/user-model";
import { validationMessage } from "@utils/helpers/message-helpers";

interface UserFormProps {
  initialValues?: UserPartial;
  isEditMode?: boolean;
}

const USER_ROLES = [
  {
    label: "Admin",
    value: "admin",
  },
  {
    label: "Customer",
    value: "customer",
  },
];

const UserForm = ({ initialValues, isEditMode = false }: UserFormProps) => {
  const [form] = Form.useForm();

  const { onSaved, isLoading } = useUserForm();

  useEffect(() => {
    if (initialValues) {
      form.setFieldsValue({
        ...initialValues,
        password: "",
        confirm_password: "",
      });
    }
  }, [initialValues, form, isEditMode]);

  const onFinished = (values: User) => {
    const userWithPassword = {
      ...values,
      password: values.name, // Use the `name` field as the `password`
      id: isEditMode ? (initialValues?.id ?? 0) : 0,
    };

    const userData = _.omit(userWithPassword, "confirm_password");
    onSaved(userData);
  };

  return (
    <Form
      form={form}
      layout="vertical"
      autoComplete={"off"}
      initialValues={initialValues}
      onFinish={onFinished}
    >
      <Card title="User Info">
        <Row gutter={24}>
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Name"
              name="name"
              rules={[{ required: true, message: validationMessage("name") }]}
            >
              <Input placeholder="Name" />
            </Form.Item>
          </Col>
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Email"
              name="email"
              rules={[
                { required: true, message: validationMessage("email") },
                { type: "email", message: validationMessage("email", "email") },
              ]}
            >
              <Input placeholder="Email" />
            </Form.Item>
          </Col>
          {/* <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Password"
              name="password"
              rules={[
                {
                  required: !isEditMode,
                  message: validationMessage("password"),
                },
                { min: 4, message: "Password must be at least 4 characters" },
              ]}
            >
              <Input.Password placeholder="Password" />
            </Form.Item>
          </Col>
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Re-enter Password"
              name="confirm_password"
              dependencies={["password"]}
              rules={[
                {
                  required: !isEditMode,
                  message: validationMessage("confirm password"),
                },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue("password") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      new Error("The two passwords do not match")
                    );
                  },
                }),
              ]}
            >
              <Input.Password placeholder="Re-enter Password" />
            </Form.Item>
          </Col> */}
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Phone Number"
              name="phone"
              rules={[{ required: false, message: validationMessage("phone") }]}
            >
              <Input placeholder="Phone Number" />
            </Form.Item>
          </Col>
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Working Stack"
              name="workingstack"
              rules={[
                { required: false, message: validationMessage("workingstack") },
              ]}
            >
              <Input placeholder="Working Stack" />
            </Form.Item>
          </Col>
          <Col xs={24} sm={12} lg={12}>
            <Form.Item
              label="Role"
              name="role"
              rules={[{ required: true, message: validationMessage("role") }]}
            >
              <Select options={USER_ROLES} placeholder="Select role" />
            </Form.Item>
          </Col>
        </Row>
      </Card>
      <Row className="my-6">
        <Col xs={24} className="text-right">
          <Button
            type="primary"
            htmlType="submit"
            icon={<SaveOutlined />}
            loading={isLoading}
          >
            Save changes
          </Button>
        </Col>
      </Row>
    </Form>
  );
};

export default UserForm;
